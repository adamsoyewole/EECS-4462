/*
  ==============================================================================
    This file contains the basic framework code for a JUCE plugin editor.
  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
A2StarterAudioProcessorEditor::A2StarterAudioProcessorEditor(A2StarterAudioProcessor& p)
    : AudioProcessorEditor(&p), audioProcessor(p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize(650, 450);


    // parameters that define the drySound slider
    drySoundSlider.setSliderStyle(juce::Slider::LinearBarVertical);
    drySoundSlider.setRange(0.0, 100.0, 1.0);
    drySoundSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
    drySoundSlider.setPopupDisplayEnabled(true, false, this);
    drySoundSlider.setTextValueSuffix("The wet %");
    drySoundSlider.setValue(100.0);


    addAndMakeVisible(&drySoundSlider);
    drySoundSlider.addListener(this);

    // parameters that define the wetSound slider
    wetSoundSlider.setSliderStyle(juce::Slider::LinearBarVertical);
    wetSoundSlider.setRange(0.0, 100.0, 1.0);
    wetSoundSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
    wetSoundSlider.setPopupDisplayEnabled(true, false, this);
    wetSoundSlider.setTextValueSuffix("The wet %");
    wetSoundSlider.setValue(0.0);


    addAndMakeVisible(&wetSoundSlider);
    wetSoundSlider.addListener(this);

    // parameters that define the time slider
    timeSlider.setSliderStyle(juce::Slider::LinearBarVertical);
    timeSlider.setRange(0.0, 3.0, 0.05);
    timeSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
    timeSlider.setPopupDisplayEnabled(true, false, this);
    timeSlider.setTextValueSuffix("The time (in seconds)");
    timeSlider.setValue(0);


    addAndMakeVisible(&timeSlider);
    timeSlider.addListener(this);

    // parameters that define the feedback slider
    feedbackSlider.setSliderStyle(juce::Slider::LinearBarVertical);
    feedbackSlider.setRange(0.0, 100.0, 1.0);
    feedbackSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 90, 0);
    feedbackSlider.setPopupDisplayEnabled(true, false, this);
    feedbackSlider.setTextValueSuffix("% Feedback");
    feedbackSlider.setValue(0.0);


    addAndMakeVisible(&feedbackSlider);
    feedbackSlider.addListener(this);





    enum RadioButtonIDs {
        customButtons = 1001
    };
    pingpongButton.onClick = [this] { pingpongSet(&pingpongButton, pingpongButton.getButtonText());   };
    getLookAndFeel().setColour(juce::TextButton::buttonColourId, juce::Colours::blue);

    pingpongButton.setRadioGroupId(customButtons);
    addAndMakeVisible(pingpongButton);



}

A2StarterAudioProcessorEditor::~A2StarterAudioProcessorEditor()
{
}

//==============================================================================
void A2StarterAudioProcessorEditor::paint(juce::Graphics& g)
{
    // fill the whole window white
    g.fillAll(juce::Colours::white);

    // set the current drawing colour to black
    g.setColour(juce::Colours::black);

    // set the font size and draw text to the screen
    g.setFont(15.0f);

    g.drawFittedText("Assignment2 Delay", 0, 0, getWidth(), 30, juce::Justification::centred, 1);
    g.drawFittedText("The time interval", timeSlider.getX()-20, timeSlider.getY() - 30, 80, 30, juce::Justification::centredLeft, 1);
    g.drawFittedText("The dry sound", drySoundSlider.getX(), drySoundSlider.getY()-30, 80, 30, juce::Justification::centredLeft, 1);
    g.drawFittedText("The wet sound", wetSoundSlider.getX(), wetSoundSlider.getY()-30, 80, 30, juce::Justification::centredLeft, 1);
    g.drawFittedText("The feedback", feedbackSlider.getX()-20, feedbackSlider.getY() - 30, 80, 30, juce::Justification::centredLeft, 1);
    g.drawFittedText("PingPong", pingpongButton.getX()-20, pingpongButton.getY() - 30, 80, 30, juce::Justification::centredLeft, 1);
}

void A2StarterAudioProcessorEditor::resized()
{

    timeSlider.setBounds(40, 50, 20, getHeight() - 60);
    drySoundSlider.setBounds(timeSlider.getX() + 80, 50, 20, getHeight() - 60);
    wetSoundSlider.setBounds(drySoundSlider.getX() + 80, 50, 20, getHeight() - 60);
    feedbackSlider.setBounds(wetSoundSlider.getX() + 80, 50, 20, getHeight() - 60);
    pingpongButton.setBounds(feedbackSlider.getX() + 80, drySoundSlider.getHeight() / 2 + 30, 40, 40);
}

void A2StarterAudioProcessorEditor::sliderValueChanged(juce::Slider* slider)
{
    audioProcessor.drySound = drySoundSlider.getValue();
    audioProcessor.wetSound = wetSoundSlider.getValue();
    audioProcessor.feedback = feedbackSlider.getValue();
    audioProcessor.time = timeSlider.getValue();



}
void A2StarterAudioProcessorEditor::pingpongSet(juce::TextButton* button, juce::String state) {
    if (state == "Off") {
        audioProcessor.pingpong = true;
        button->setButtonText("On");
        button->setColour(juce::TextButton::buttonColourId, juce::Colours::black);
    }
    else {
        audioProcessor.pingpong = false;
        button->setButtonText("Off");
        button->setColour(juce::TextButton::buttonColourId, juce::Colours::blue);
    }
}
