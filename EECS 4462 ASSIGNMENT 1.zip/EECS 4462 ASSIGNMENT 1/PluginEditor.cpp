/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
ArpeggiatorEditor::ArpeggiatorEditor (Arpeggiator& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (300, 200);

	notespeedLabel.setText("The speed:", NotificationType::dontSendNotification);
	notespeedLabel.setJustificationType(juce::Justification::centredRight);
	notespeedLabel.attachToComponent(&speedSlider, true);
	addAndMakeVisible(speedLabel);

    notespeedSlider.setSliderStyle (juce::Slider::SliderStyle::LinearHorizontal);
    notespeedSlider.setRange (0.0, 1.0, 0.05);
    notespeedSlider.setTextBoxStyle (juce::Slider::TextEntryBoxPosition::NoTextBox, true, 90, 20);
    notespeedSlider.setPopupDisplayEnabled (true, true, this);
    notespeedSlider.setValue(0.5);
    addAndMakeVisible (&notespeedSlider);
	notespeedSlider.onValueChange = [this] {updateSpeed(); };

	notedurationLabel.setText("The duration of the first note is:", NotificationType::dontSendNotification);
	notedurationLabel.setJustificationType(juce::Justification::centredRight);
	notedurationLabel.attachToComponent(&notedurationSlider, true);
	addAndMakeVisible(notedurationLabel);

	notedurationSlider.setSliderStyle(juce::Slider::SliderStyle::LinearHorizontal);
	notedurationSlider.setRange(0.25, 4.0, 0.25);
	notedurationSlider.setTextBoxStyle(juce::Slider::TextEntryBoxPosition::NoTextBox, true, 90, 20);
	notedurationSlider.setPopupDisplayEnabled(true, true, this);
	notedurationSlider.setValue(1.0);
	addAndMakeVisible(&notedurationSlider);
	notedurationSlider.onValueChange = [this] {updateDuration(); };

	noteascendToggle.setToggleState(true, NotificationType::dontSendNotification);
	addAndMakeVisible(noteascendToggle);
	noteascendToggle.onClick = [this] {updateAscending(); };

	sequenceLabel.setText("The sequence is:", NotificationType::dontSendNotification);
	addAndMakeVisible(sequenceLabel);

	linearToggle.setToggleState(true, NotificationType::dontSendNotification);
	addAndMakeVisible(linearToggle);
	linearToggle.onClick = [this] {updateSequence(); };
	linearToggle.setRadioGroupId(1);

	noteshuffleToggle.setToggleState(false, NotificationType::dontSendNotification);
	addAndMakeVisible(noteshuffleToggle);
	noteshuffleToggle.onClick = [this] {updateSequence(); };
	noteshuffleToggle.setRadioGroupId(1);

	noterepeatToggle.setToggleState(false, NotificationType::dontSendNotification);
	addAndMakeVisible(noterepeatToggle);
	noterepeatToggle.onClick = [this] {updateSequence(); };
	noterepeatToggle.setRadioGroupId(1);

	addAndMakeVisible(octaveCombo);
	octaveCombo.addItem("1 octave", 1);
	octaveCombo.addItem("2 octaves", 2);
	octaveCombo.addItem("3 octaves", 3);
	octaveCombo.onChange = [this] {updateOctaves(); };
	octaveCombo.setSelectedId(1);
}

ArpeggiatorEditor::~ArpeggiatorEditor()
{
}

//==============================================================================
void ArpeggiatorEditor::paint (juce::Graphics& g)
{

	g.fillAll(juce::Colours::white);
    //g.fillAll (juce::Colour::Colour(143, 55, 163));

	g.setColour(juce::Colours::blue);
	g.fillRoundedRectangle(199, 80, 2, 120, 1);
}

void ArpeggiatorEditor::resized()
{
    notespeedSlider.setBounds (100, 10, getWidth() - 100, 10);
	notedurationSlider.setBounds(100, 40, getWidth() - 100, 10);

	noteascendToggle.setBounds(200, 80, 170, 20);
	octaveCombo.setBounds(200, 100, 170, 20);

	sequenceLabel.setBounds(10, 70, 160, 10);
	linearToggle.setBounds(10, 110, 160, 10);
	noteshuffleToggle.setBounds(10, 120, 160, 10);
	noterepeatToggle.setBounds(10, 140, 160, 10);
}

void ArpeggiatorEditor::updateSpeed()
{
	audioProcessor.notespeed = notespeedSlider.getValue();
}

void ArpeggiatorEditor::updateDuration()
{
	audioProcessor.noteduration = notedurationSlider.getValue();
}

void ArpeggiatorEditor::updateAscending()
{
	audioProcessor.noteascend = noteascendToggle.getToggleState();
}

void ArpeggiatorEditor::updateSequence()
{
	audioProcessor.noteshuffle = noteshuffleToggle.getToggleState();
	audioProcessor.noterepeat = noterepeatToggle.getToggleState();
}

void ArpeggiatorEditor::updateOctaves()
{
	audioProcessor.octave = octaveCombo.getSelectedId();
}
