/*
  ==============================================================================

    This file contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class ArpeggiatorEditor  : public juce::AudioProcessorEditor
{
public:
    ArpeggiatorEditor (Arpeggiator&);
    ~ArpeggiatorEditor() override;

    //==============================================================================
    void paint (juce::Graphics&) override;
    void resized() override;

private:
	void updateSequence();
	void updateAscending();
  void updateSpeed();
	void updateOctaves();
  void updateDuration();
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    Arpeggiator& audioProcessor;

	juce::Label notespeedLabel{ "The speed" };
    juce::Slider notespeedSlider;
	juce::Label notedurationLabel{ "The duration of the first note is:" };
	juce::Slider notedurationSlider;
	juce::ToggleButton noteascendToggle{ "Ascending sequence" };
	juce::Label sequenceLabel{ "The sequence is" };
	juce::ToggleButton linearToggle{ "Linear" };
	juce::ToggleButton noteshuffleToggle{ "Now randomize the notes" };
	juce::ToggleButton noterepeatToggle{ "Repeat the first note" };
	juce::ComboBox octaveCombo;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ArpeggiatorEditor)
};
